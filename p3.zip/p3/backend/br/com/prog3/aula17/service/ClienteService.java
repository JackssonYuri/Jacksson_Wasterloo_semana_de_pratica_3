package br.com.prog3.aula17.service;

import br.com.prog3.aula17.domain.Cliente;
import br.com.prog3.aula17.repository.ClienteRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClienteService {
   @Autowired
   private ClienteRepository clienteRepository;

   public Cliente save(Cliente cliente) {
      return this.clienteRepository.save(cliente);
   }

   public List findAll() {
      return this.clienteRepository.findAll();
   }

   public Optional findById(Long id) {
      return this.clienteRepository.findById(id);
   }

   public List findByIdade(int idade) {
      return this.clienteRepository.findByIdade(idade);
   }

   public Cliente update(Cliente cliente) {
      return this.clienteRepository.save(cliente);
   }

   public void deleteById(Long id) {
      this.clienteRepository.deleteById(id);
   }
}
