package br.com.prog3.aula17.repository;

import br.com.prog3.aula17.domain.Cliente;
import java.util.List;
import java.util.Optional;
import org.springframework.data.repository.CrudRepository;

public interface ClienteRepository extends CrudRepository {
   List findByIdade(int idade);

   Cliente save(Cliente cliente);

   List findAll();

   Optional findById(Long id);

   void deleteById(Long id);
}
