# Programação de Computadores III - Semana de prática 3

Descrição da atividade
 - Crie o backend (webservice).
 - Crie o frontend, ligando o backend com o frontend.
 - Com base no que foi aprendido no curso de Vue, melhore a interface da aplicação.